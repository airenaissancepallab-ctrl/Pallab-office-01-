import { useEffect, useState, useRef } from 'react';

export const useScrollAnimation = (options?: IntersectionObserverInit) => {
  const ref = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      // If the element is intersecting (in view)
      if (entry.isIntersecting) {
        setIsVisible(true);
        // We can unobserve the element after the animation has been triggered once
        if (ref.current) {
            observer.unobserve(ref.current);
        }
      }
    }, {
      threshold: 0.1, // Trigger when 10% of the element is visible
      ...options
    });

    if (ref.current) {
      observer.observe(ref.current);
    }

    // Cleanup observer on component unmount
    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [ref, options]);

  return { ref, isVisible };
};
