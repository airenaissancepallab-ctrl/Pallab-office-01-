
import React from 'react';
import type { Service, Testimonial, FaqItem } from './types';

const ScaleIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0 0 12 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52v1.666c0 .414-.168.79-.44 1.06a2.463 2.463 0 0 1-1.06.44H4.44a2.463 2.463 0 0 1-1.06-.44 1.463 1.463 0 0 1-.44-1.06V5.49a48.567 48.567 0 0 1 3-.52m-3 .52a48.064 48.064 0 0 0-3-.52c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52M3.75 4.97a48.416 48.416 0 0 1 16.5 0" />
  </svg>
);

const DocumentTextIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
    </svg>
);

const MagnifyingGlassIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
    </svg>
);

export const SERVICES_DATA: Service[] = [
  {
    icon: <ScaleIcon className="h-10 w-10 text-gold" />,
    title: 'Legal Consultation',
    description: 'Expert advice to navigate complex legal landscapes. We provide clarity and strategic direction for your legal concerns.'
  },
  {
    icon: <DocumentTextIcon className="h-10 w-10 text-gold" />,
    title: 'Document Drafting',
    description: 'Meticulous drafting of legal documents, contracts, and agreements to protect your interests and ensure compliance.'
  },
  {
    icon: <MagnifyingGlassIcon className="h-10 w-10 text-gold" />,
    title: 'Legal Research',
    description: 'In-depth legal research and analysis to build strong cases and provide well-founded legal opinions.'
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    quote: "The guidance I received was not only professional but also delivered with genuine care and understanding. A truly remarkable service.",
    name: "A. Sharma",
    title: "Satisfied Client"
  },
  {
    quote: "Clarity, honesty, and timely action are not just words on a website; they are the principles this practice is built on. Highly recommended.",
    name: "R. Singh",
    title: "Business Owner"
  },
  {
    quote: "Navigating the legal system was daunting, but I felt supported every step of the way. The expertise and dedication were exceptional.",
    name: "P. Dutta",
    title: "Client"
  }
];

export const FAQ_DATA: FaqItem[] = [
  {
    question: "What are your areas of specialization?",
    answer: "I specialize in legal consultation, document drafting, and in-depth legal research across various domains of law to provide comprehensive support to my clients."
  },
  {
    question: "How do I book an appointment?",
    answer: "You can book an appointment by clicking the 'Book Appointment' button on the website, which will guide you through the process, or by contacting me directly via the provided WhatsApp number or contact form."
  },
  {
    question: "What should I bring to my first consultation?",
    answer: "For your initial consultation, please bring all relevant documents related to your case, a form of identification, and a list of any questions you may have. This will help us make the most of our time together."
  },
  {
    question: "Where is your working office located?",
    answer: "My working office is conveniently located at Purulia Court in Purulia, West Bengal. Detailed directions can be provided upon scheduling an appointment."
  }
];
