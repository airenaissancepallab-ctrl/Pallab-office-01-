import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const About: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      id="about" 
      ref={ref}
      className={`py-20 lg:py-32 bg-white transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-6">About Me</h2>
            <p className="font-sans text-lg text-charcoal/80 mb-4">
              I am Pallab Kumar Gorai, a dedicated legal professional based in Purulia, West Bengal, with my working office at Purulia Court. My foundation in law was built at the esteemed Imamul Hai Khan Law College, Bokaro.
            </p>
            <p className="font-sans text-lg text-charcoal/80 mb-6">
              My practice is built on a commitment to providing clients with clear, honest, and effective legal solutions. I believe in a client-centric approach, ensuring that you are informed and empowered throughout the legal process. My goal is to navigate complexities on your behalf and achieve the best possible outcomes with integrity and professionalism.
            </p>
            <a href="#contact" className="bg-royal-blue text-white font-bold py-3 px-8 rounded-full text-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 shadow-md">
              Contact Me
            </a>
          </div>
          <div className="order-1 lg:order-2 flex items-center justify-center">
             <img 
              src="https://images.unsplash.com/photo-1589578236809-c44d87391a22?q=80&w=800&auto=format&fit=crop" 
              alt="Pallab Kumar Gorai - Legal Professional" 
              className="rounded-lg shadow-xl w-full max-w-sm h-auto object-cover aspect-[4/5] transform transition-all duration-500 hover:scale-105 hover:shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;