import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const Contact: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation();
  
  return (
    <section 
      id="contact" 
      ref={ref}
      className={`py-20 lg:py-32 bg-charcoal text-white transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="container mx-auto px-6 text-center">
        <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">Ready to Discuss Your Case?</h2>
        <p className="font-sans text-lg text-cream/80 max-w-3xl mx-auto mb-8">
          Reach out today for a consultation. Let's work together to find the right legal path for you. Your peace of mind is my priority.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <div className="text-center">
                <p className="font-bold text-gold">Location</p>
                <p>Working Office: Purulia Court</p>
                <p>Purulia, West Bengal</p>
            </div>
             <div className="text-center">
                <p className="font-bold text-gold">Contact</p>
                <p>Email: pallabgorain50@gmail.com</p>
                <p>Phone: +91-XXX-XXX-XXXX</p>
            </div>
        </div>
        <div className="mt-12">
            <a href="mailto:pallabgorain50@gmail.com" className="bg-gold text-charcoal font-bold py-4 px-10 rounded-full text-xl hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg">
                Book a Free Consultation
            </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;