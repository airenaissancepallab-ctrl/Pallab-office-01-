import React from 'react';
import { SERVICES_DATA } from '../constants';
import type { Service } from '../types';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => (
  <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer border-t-4 border-transparent hover:border-gold group">
    <div className="mb-4 transition-transform duration-300 group-hover:scale-110">{service.icon}</div>
    <h3 className="font-serif text-2xl font-semibold text-charcoal mb-3">{service.title}</h3>
    <p className="font-sans text-charcoal/80 leading-relaxed">{service.description}</p>
  </div>
);

const Services: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      id="services" 
      ref={ref}
      className={`py-20 lg:py-32 bg-cream transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="container mx-auto px-6 text-center">
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">Our Services</h2>
        <p className="font-sans text-lg text-charcoal/80 max-w-3xl mx-auto mb-12">
          Providing comprehensive legal support with a focus on professionalism, integrity, and client success.
        </p>
        <div className="max-w-4xl mx-auto mb-16">
            <img 
              src="https://images.unsplash.com/photo-1599249300664-dd8842b35a42?q=80&w=1200&auto=format&fit=crop" 
              alt="Legal Services Illustration - Gavel and law books" 
              className="rounded-lg shadow-xl w-full h-auto transform transition-all duration-500 hover:scale-105"
            />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES_DATA.map((service, index) => (
            <ServiceCard key={index} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;