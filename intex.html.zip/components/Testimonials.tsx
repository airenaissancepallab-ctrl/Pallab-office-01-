import React from 'react';
import { TESTIMONIALS_DATA } from '../constants';
import type { Testimonial } from '../types';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const QuoteIcon: React.FC = () => (
    <svg className="w-12 h-12 text-gold opacity-30" fill="currentColor" viewBox="0 0 32 32" aria-hidden="true">
        <path d="M9.333 4C4.167 4 0 8.167 0 13.333c0 4.142 2.667 7.725 6.333 8.983.167-.5.25-.917.25-1.417 0-1.416-.5-2.583-1.583-3.583C6.167 16.167 7 14.5 7 12.5c0-1.917-1.083-3.417-3.25-4.5C4.75 7.583 6.667 4 9.333 4zm18.667 0C23.167 4 19 8.167 19 13.333c0 4.142 2.667 7.725 6.333 8.983.167-.5.25-.917.25-1.417 0-1.416-.5-2.583-1.583-3.583.583-1.167 1.417-2.833 1.417-4.833 0-1.917-1.083-3.417-3.25-4.5.917-.417 2.833-3.5 5.5-3.5z"/>
    </svg>
);

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => (
    <div className="bg-cream p-8 rounded-lg shadow-lg relative h-full flex flex-col justify-between">
        <div className="absolute top-6 left-6">
            <QuoteIcon />
        </div>
        <p className="font-sans text-lg text-charcoal/90 italic mt-8 mb-6 z-10">
            "{testimonial.quote}"
        </p>
        <div className="z-10 mt-auto">
            <p className="font-bold text-charcoal">{testimonial.name}</p>
            <p className="text-sm text-charcoal/70">{testimonial.title}</p>
        </div>
    </div>
);

const Testimonials: React.FC = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      id="testimonials" 
      ref={ref}
      className={`py-20 lg:py-32 bg-white transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="container mx-auto px-6 text-center">
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">What Clients Say</h2>
        <p className="font-sans text-lg text-charcoal/80 max-w-3xl mx-auto mb-12">
          Building trust through dedicated service and successful outcomes.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
