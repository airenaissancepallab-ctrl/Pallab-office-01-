import React, { useState, useEffect } from 'react';

// A simple, local spinner component to show while the main image loads.
const Spinner: React.FC<{ message?: string }> = ({ message }) => {
  return (
    <div className="relative z-10 text-center text-white px-4">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold mx-auto"></div>
      {message && <p className="mt-4 text-lg font-sans">{message}</p>}
    </div>
  );
};

const Hero: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const backgroundImageUrl = 'https://images.unsplash.com/photo-1505664194779-8be224216294?q=80&w=1920&auto=format&fit=crop';

  useEffect(() => {
    const img = new Image();
    img.src = backgroundImageUrl;
    img.onload = () => {
      // A small delay for a smoother visual transition after the image loads
      setTimeout(() => setIsLoading(false), 300);
    };
    img.onerror = () => {
      // If the image fails to load, still show the content
      setIsLoading(false);
    };
  }, []);

  return (
    <section 
      className="h-screen w-full flex items-center justify-center relative bg-cover bg-center" 
      style={{ 
        backgroundImage: `url('${backgroundImageUrl}')`
      }}
    >
      <div className="absolute inset-0 bg-deep-purple opacity-70"></div>
      
      {isLoading ? (
        <Spinner message="Crafting a first impression..." />
      ) : (
        <div className="relative z-10 text-center text-white px-4">
          <h1 
            className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight opacity-0 animate-fadeInUp"
            style={{ animationDelay: '0.2s' }}
          >
            Pallab Kumar Gorai
          </h1>
          <p 
            className="text-xl md:text-2xl mb-2 font-light opacity-0 animate-fadeInUp"
            style={{ animationDelay: '0.4s' }}
          >
            B.A, LL.B (Intend)
          </p>
          <p 
            className="text-lg md:text-xl max-w-3xl mx-auto font-sans mb-8 text-cream/90 opacity-0 animate-fadeInUp"
            style={{ animationDelay: '0.6s' }}
          >
            Trusted Legal Guidance in Purulia.
            <br />
            Clarity, honesty, and timely action for every client.
          </p>
          <div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 opacity-0 animate-fadeInUp"
            style={{ animationDelay: '0.8s' }}
          >
            <a href="#contact" className="bg-gold text-charcoal font-bold py-3 px-8 rounded-full text-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 shadow-lg animate-pulseSlow">
              Book Appointment
            </a>
            <a href="https://wa.me/qr/SOTWGEYA74EMM1" target="_blank" rel="noopener noreferrer" className="bg-transparent border-2 border-white text-white font-bold py-3 px-8 rounded-full text-lg hover:bg-white hover:text-charcoal transition-all duration-300 transform hover:scale-105">
              WhatsApp Now
            </a>
          </div>
        </div>
      )}
    </section>
  );
};

export default Hero;