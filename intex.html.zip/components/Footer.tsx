
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white py-8">
      <div className="container mx-auto px-6 text-center text-charcoal/70">
        <p>&copy; {new Date().getFullYear()} Pallab Kumar Gorai. All Rights Reserved.</p>
        <p className="text-sm mt-2">Designed with elegance and professionalism.</p>
        <div className="flex justify-center space-x-6 mt-4">
            <a href="https://www.linkedin.com/in/your-profile" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors duration-300">LinkedIn</a>
            <a href="https://twitter.com/your-profile" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors duration-300">Twitter</a>
            <a href="https://facebook.com/your-profile" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors duration-300">Facebook</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;